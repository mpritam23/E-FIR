import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-citizen',
  templateUrl: './user-citizen.component.html',
  styleUrls: ['./user-citizen.component.css']
})
export class UserCitizenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
