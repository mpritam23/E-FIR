import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserPcrComponent } from './user-pcr.component';

describe('UserPcrComponent', () => {
  let component: UserPcrComponent;
  let fixture: ComponentFixture<UserPcrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserPcrComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserPcrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
