import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-pcr',
  templateUrl: './user-pcr.component.html',
  styleUrls: ['./user-pcr.component.css']
})
export class UserPcrComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
