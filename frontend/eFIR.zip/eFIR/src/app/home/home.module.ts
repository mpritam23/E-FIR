import { CommonModule } from "@angular/common";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { LodgeComplaintComponent } from "../lodgeComplaint/lodgecomplaint.component";
import { PermissionRequestComponent } from "../permission-request/permission-request.component";
import { PoliceStationsListComponent } from "../policestations/pslist.component";
import { RegisterComponent } from "../register/register.component";
import { TrackComplaintComponent } from "../trackComplaint/track.component";
import { HomeRoutingModule } from "./home-routing.module";

@NgModule({
    declarations:[LodgeComplaintComponent,PoliceStationsListComponent,TrackComplaintComponent,PermissionRequestComponent],
    imports:[CommonModule,FormsModule,HomeRoutingModule]
})
export class HomeModule{}