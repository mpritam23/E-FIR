import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginformComponent} from './user/loginform.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component'
import { AboutUSComponent } from './aboutus/aboutus.component';
import { ContactComponent } from './contact/contact.component';
import { LodgeComplaintComponent } from './lodgeComplaint/lodgecomplaint.component';
import { FAQComponent } from './faq/faq.component';
import { TrackComplaintComponent } from './trackComplaint/track.component';
import { PoliceStationsListComponent } from './policestations/pslist.component';
@NgModule({
  declarations: [
    AppComponent,LoginformComponent, UserComponent,
     PageNotFoundComponent, HomeComponent,AboutUSComponent,RegisterComponent,ContactComponent,
     LodgeComplaintComponent,FAQComponent,TrackComplaintComponent,PoliceStationsListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
