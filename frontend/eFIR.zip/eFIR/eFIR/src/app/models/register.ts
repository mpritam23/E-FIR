export class Register{
    id:string;
    password:string;
    role:string;
    constructor(id:string,password:string,role:string){
        this.id=id;
        this.password=password;
        this.role=role;
    }
}