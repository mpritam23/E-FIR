import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserCitizenComponent } from './user-citizen.component';

describe('UserCitizenComponent', () => {
  let component: UserCitizenComponent;
  let fixture: ComponentFixture<UserCitizenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserCitizenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserCitizenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
