import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { LodgeComplaintComponent } from "../lodgeComplaint/lodgecomplaint.component";
import { PermissionRequestComponent } from "../permission-request/permission-request.component";
import { PoliceStationsListComponent } from "../policestations/pslist.component";
import { TrackComplaintComponent } from "../trackComplaint/track.component";
import { HomeComponent } from "./home.component";

const routes:Routes=[{path:"Home",children:[
                                        {path:"",component:HomeComponent},
                                        {path:"lodgeComplaint",component:LodgeComplaintComponent},
                                        {path:"TrackComplaint",component:TrackComplaintComponent},
                                        {path:"PoliceStationList",component:PoliceStationsListComponent},
                                        {path:"PermissionRequest",component:PermissionRequestComponent},
                                        ]}
                    

];/* As is routing module is for Home, meaning when we'll click on lodgeComplaint URL will be "Home/lodgeComplaint" ,
 it means lodgecomplaint is child of Home. So, to route it in that way, 
 we have to add a children array in routes array after path as shown above */

@NgModule({
    imports:[RouterModule.forChild(routes)]//As this routing is done for a component which is child of app component, so we have to use forchild() method
    ,
    exports:[RouterModule]
})
export class HomeRoutingModule{}