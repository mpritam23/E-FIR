import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-police-station',
  templateUrl: './user-police-station.component.html',
  styleUrls: ['./user-police-station.component.css']
})
export class UserPoliceStationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
