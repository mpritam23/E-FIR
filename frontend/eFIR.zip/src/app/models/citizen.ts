export class Citizen{
    id:string;
    citizen_name:string;
    citizen_email:string;
    citizen_contactNo:number;
    citizen_password:string;

     constructor(citizen_id:string,citizen_name:string,citizen_email:string,citizen_contactNo:number,citizen_password:string)
    {
        this.id=citizen_id;
        this.citizen_name=citizen_name;
        this.citizen_email=citizen_email;
        this.citizen_contactNo=citizen_contactNo;
        this.citizen_password=citizen_password;
    } 
}