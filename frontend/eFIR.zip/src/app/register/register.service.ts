import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Register } from "../models/register";
import { Citizen } from "../models/citizen";
@Injectable()
export class RegisterService{
    baseUrl="http://localhost:3000";

    constructor(private httpC:HttpClient){}

    getID():Observable<string>{
        return this.httpC.get<string>(this.baseUrl+'/register/:id');
    }

    addCitizen(c:Citizen):Observable<Citizen[]>{
        return this.httpC.post<Citizen[]>(this.baseUrl+"/citizen",c);
    }

}