import { Component, OnInit } from '@angular/core';
import { Citizen } from '../models/citizen';
import { Register } from '../models/register';
import { RegisterService } from './register.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  id:string
  uname:string
  emailid:string
  passw:string
  contactno:number
  showRegistrationForm:Boolean=true;
  showSuccessMessage:Boolean=false;
  carr:Citizen[];
  rarr:Register[];

  constructor(private rService:RegisterService) { }

  ngOnInit(): void {
  }

  addUser()//Regiters Citizen.
  {
    let c=new Citizen(this.id,this.uname,this.emailid,this.contactno,this.passw);
    let r=new Register(this.id,this.passw,"citizen");
    
    this.rService.addCitizen(c)
    .subscribe(result1=>this.carr=result1);
    this.id=this.carr[0].id;
    this.showRegistrationForm=false;
    this.showSuccessMessage=true;
  }

}
