import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Citizen } from '../models/citizen';
import { UserCitizenComponent } from '../user/user-citizen/user-citizen.component';
import { LoginService } from './login.service';

@Component({
  selector: 'loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginformComponent {
  id:string;
  passw:string;
  uname:string;
  showWelcomePage:boolean=false;
  showInvalidUser:boolean=false;
  showLoginForm:boolean=true
  _citizen:Citizen;
  constructor(private lService:LoginService,private router:Router){}
 
  loginForward(){
    
  }
  loginAttempt(){
    
    this.lService.loginAttempt(this.id,this.passw)
    .subscribe(result=>this._citizen=result);
    console.log(this._citizen);
  
    if(this._citizen){
    if(this._citizen.id==this.id && this._citizen.citizen_password==this.passw)
    {
      this.uname=this._citizen.citizen_name;
      this.router.navigate(['/user/user-citizen']);
      /* this.showWelcomePage=true;
      this.showLoginForm=false;
      this.showInvalidUser=false; */
    }
    }else{
      this.showWelcomePage=false;
      this.showLoginForm=true;
      this.showInvalidUser=true;
    }
  }

  
}
