import { Component } from '@angular/core';

@Component({
  selector: 'lodgeComplaint',
  templateUrl: './lodgecomplaint.component.html',
  styleUrls: ['./lodgecomplaint.component.css']
})
export class LodgeComplaintComponent {
 
}
