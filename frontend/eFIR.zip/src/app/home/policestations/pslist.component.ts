import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pslist',
  templateUrl: './pslist.component.html',
  styleUrls: ['./pslist.component.css']
})
export class PoliceStationsListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
