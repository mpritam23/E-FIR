import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './user/user.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component'
import { AboutUSComponent } from './aboutus/aboutus.component';
import { ContactComponent } from './contact/contact.component';
import { FAQComponent } from './faq/faq.component';
import { HomeModule } from './home/home.module';
import { LoginformComponent } from './loginform/loginform.component';
import { HttpClientModule } from '@angular/common/http';
import { RegisterService } from './register/register.service';
import { FormsModule } from '@angular/forms';
import { LoginService } from './loginform/login.service';
import { UserCitizenComponent } from './user/user-citizen/user-citizen.component';
import { UserAdminComponent } from './user/user-admin/user-admin.component';
import { UserPcrComponent } from './user/user-pcr/user-pcr.component';
import { UserPoliceStationComponent } from './user/user-police-station/user-police-station.component';

@NgModule({
  declarations: [
    AppComponent,LoginformComponent, UserComponent,
     PageNotFoundComponent, HomeComponent,AboutUSComponent,RegisterComponent,ContactComponent,
    FAQComponent,
    UserCitizenComponent,
    UserAdminComponent,
    UserPcrComponent,
    UserPoliceStationComponent,
   
  ],
  imports: [
    BrowserModule,
    HomeModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [RegisterService,LoginService],
  bootstrap: [AppComponent]
})
export class AppModule { }
