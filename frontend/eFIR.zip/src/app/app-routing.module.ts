import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUSComponent } from './aboutus/aboutus.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ContactComponent } from './contact/contact.component';
import { FAQComponent } from './faq/faq.component';
import { componentFactoryName } from '@angular/compiler';
import { LoginformComponent } from './loginform/loginform.component';
import { UserCitizenComponent } from './user/user-citizen/user-citizen.component';

const routes: Routes = [ /* Removed Home Routing because all the Routing from Home is done in home-routing.module.ts
                          If your creating saparate mapping for the components then it should not be mapped in app 
                          component,instead map them in their respenctive routing modules . Next: Home-Routing.module.ts*/
                          {path:"Login",component:LoginformComponent,pathMatch:"full"},
                          {path:"AboutUS",component:AboutUSComponent,pathMatch:"full"},
                          {path:"Contact",component:ContactComponent,pathMatch:"full"},
                          {path:"Register",component:RegisterComponent,pathMatch:"full"},
                          {path:"FAQ",component:FAQComponent,pathMatch:"full"},
                          {path:"user/user-citizen",component:UserCitizenComponent},
                          {path:"",redirectTo:"/Home",pathMatch:"full"},
                          {path:"**",component:PageNotFoundComponent}
                        ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
